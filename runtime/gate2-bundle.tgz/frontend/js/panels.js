// ==== Orai Command Center — dashboards, settings, monitor, health module ====
// Auto-split from the former monolithic app.js (M6 Phase 4c, SRP).
// Loaded as an ordered classic <script>; shares one global scope with sibling
// modules (core.js, voice.js, admin.js, cockpit.js, panels.js, app.js).

async function fetchTelemetryStats() {
    if (isBackendOffline) return;
    try {
        const response = await fetch(`${API_BASE}/runtime/status`);
        if (response.ok) {
            const data = await response.json();
            
            // Update CPU Gauge
            const cpu = data.stats.cpu || 0;
            const cpuGauge = document.getElementById('cpu-gauge');
            cpuGauge.style.background = `radial-gradient(closest-side, #080c14 79%, transparent 80% 100%), conic-gradient(var(--cyan) ${cpu}%, var(--bg-card-border) ${cpu}% 100%)`;
            document.getElementById('cpu-gauge-value').textContent = `${cpu}%`;
            
            // Update RAM Gauge
            const ram = data.stats.ram || 0;
            const ramGauge = document.getElementById('ram-gauge');
            ramGauge.style.background = `radial-gradient(closest-side, #080c14 79%, transparent 80% 100%), conic-gradient(var(--orange) ${ram}%, var(--bg-card-border) ${ram}% 100%)`;
            document.getElementById('ram-gauge-value').textContent = `${ram}%`;
            updatePollingLoadMode({ cpu, ram });
            
            // Update Text items
            const isLocal = data.mode === 'LOCAL_TEST_MODE';
            document.getElementById('telemetry-vm-mode').textContent = isLocal ? 'LOCAL TEST MODE' : 'GCP CLOUD VM';
            
            // Gauge Labels
            document.getElementById('cpu-gauge-label').textContent = isLocal ? 'Local CPU Load' : 'VM CPU Load';
            document.getElementById('ram-gauge-label').textContent = isLocal ? 'Local RAM Usage' : 'VM RAM Usage';
            
            // VM Status Row
            const vmStatusEl = document.getElementById('telemetry-vm-status');
            const statusLabelEl = document.getElementById('telemetry-status-label');
            if (isLocal) {
                statusLabelEl.textContent = 'VM Live Status:';
                vmStatusEl.textContent = 'Not checked in local mode';
                vmStatusEl.className = 'text-warning';
            } else {
                statusLabelEl.textContent = 'VM Status:';
                vmStatusEl.textContent = 'Online & Verified';
                vmStatusEl.className = 'text-success';
            }

            // Uptime Row
            const uptimeLabelEl = document.getElementById('telemetry-uptime-label');
            uptimeLabelEl.textContent = isLocal ? 'Local Process Uptime:' : 'Cloud Server Uptime:';
            document.getElementById('telemetry-uptime').textContent = data.uptime;

            // Public IP / Configured Target
            const ipLabelEl = document.getElementById('telemetry-public-ip-label');
            const ipValEl = document.getElementById('telemetry-public-ip');
            ipLabelEl.textContent = isLocal ? 'Configured Target IP:' : 'GCP Public IP:';
            ipValEl.textContent = data.public_ip || '35.244.15.150';

            // First Greeting Bubble Update
            const firstBubble = document.getElementById('console-first-bubble');
            if (firstBubble) {
                if (isLocal) {
                    firstBubble.innerHTML = "Ji sir, Command Center ready hai. Local status, source tools, approval queue aur creative work available hai. Playout aur VM live check unverified.";
                } else {
                    firstBubble.innerHTML = "Ji sir, Command Center ready hai. Playout aur VM fully stable hain. Aaj content, schedule, scripts ya station status me kya dekhna hai?";
                }
            }

            // Update Stream connection status
            const streamBadge = document.getElementById('telemetry-azuracast-status');
            const streamStatus = data.radio_stream;
            streamBadge.textContent = streamStatus;
            
            if (streamStatus === 'LIVE') {
                streamBadge.className = 'badge badge-success';
            } else if (streamStatus === 'UNKNOWN') {
                streamBadge.className = 'badge badge-warning';
            } else {
                streamBadge.className = 'badge badge-danger';
            }
            
            // Update Autopilot Mode badge
            const autoBadge = document.getElementById('telemetry-autopilot-status');
            autoBadge.textContent = `AUTO-PILOT: ${data.auto_mode}`;
            if (data.auto_mode === 'ON') {
                autoBadge.className = 'badge badge-success';
            } else {
                autoBadge.className = 'badge badge-danger';
            }
            
            // Sidebar server badge is updated from cockpit-status (fetchCockpitData)
            renderActivityLogs(data.commands);
        }
    } catch (e) {
        // Telemetry failure is non-blocking — do not mark server offline
    }
}

function renderActivityLogs(commands) {
    const container = document.getElementById('activities-scroller-container');
    if (!commands || commands.length === 0) {
        container.innerHTML = '<p class="empty-state">No activities logged yet.</p>';
        return;
    }
    
    container.innerHTML = '';
    commands.forEach(cmd => {
        const row = document.createElement('div');
        row.className = 'log-item-row';
        
        // Extract time
        const date = new Date(cmd.created_at || cmd.updated_at);
        const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        let resultMsg = 'Queued for VM execution';
        if (cmd.result_json) {
            try {
                resultMsg = JSON.parse(cmd.result_json).message || cmd.status;
            } catch (e) {}
        }
        
        row.innerHTML = `<span class="time">[${timeStr}]</span> <strong>${cmd.command_type}</strong>: ${resultMsg}`;
        container.appendChild(row);
    });
}

// Live Playout Streaming Audio Toggle
function toggleDashboardAudio() {
    const player = document.getElementById('dashboard-stream-player');
    const disc = document.getElementById('vinyl-disc');
    const playBtn = document.getElementById('player-play-btn');
    
    if (player.paused) {
        player.load();
        player.play().then(() => {
            disc.classList.add('spinning');
            playBtn.innerHTML = '<i class="fa-solid fa-pause"></i>';
        }).catch(err => {
            alert('Live stream play failure: server buffer is currently syncing or offline.');
        });
    } else {
        player.pause();
        disc.classList.remove('spinning');
        playBtn.innerHTML = '<i class="fa-solid fa-play"></i>';
    }
}

async function fetchNowPlayingMetadata() {
    try {
        const res = await fetch(`${API_BASE}/public/now-playing`);
        if (res.ok) {
            const data = await res.json();
            document.getElementById('player-track-title').textContent = data.title;
            document.getElementById('player-track-artist').textContent = data.artist;
            // Dynamically set the audio player source if stream URL is available
            if (data.stream_url) {
                const player = document.getElementById('dashboard-stream-player');
                if (player && !player.src) {
                    player.src = data.stream_url;
                }
            }
        }
    } catch(e) {}
}


// 5. NEENA LAB DATA FETCHER
let neenaLabInterval = null;

async function fetchNeenaLabData() {
    try {
        const res = await fetch(`${API_BASE}/neena/lab`);
        if (!res.ok) return;
        const data = await res.json();

        // Mode badge
        const modeBadge = document.getElementById('neena-lab-mode-badge');
        if (modeBadge) modeBadge.textContent = data.mode || 'LOCAL_TEST_MODE';

        // Current Task
        const taskEl = document.getElementById('neena-lab-current-task');
        if (taskEl) {
            if (data.current_task && data.current_task.status !== 'idle') {
                taskEl.innerHTML = `<p><strong>${data.current_task.title || 'Working...'}</strong> — ${data.current_task.status}</p>`;
            } else {
                taskEl.innerHTML = '<p class="empty-state">Neena is idle. No active task.</p>';
            }
        }

        // Script Drafts
        const draftsEl = document.getElementById('neena-lab-script-drafts');
        if (draftsEl) {
            if (data.script_drafts && data.script_drafts.length > 0) {
                draftsEl.innerHTML = data.script_drafts.map(d =>
                    `<div class="lab-item-row">
                        <span class="badge badge-warning">${d.type}</span>
                        <span>${d.content_preview || '(empty)'}...</span>
                        <span class="lab-item-meta">${d.status} | ${d.created_at || ''}</span>
                    </div>`
                ).join('');
            } else {
                draftsEl.innerHTML = '<p class="empty-state">No script drafts.</p>';
            }
        }

        // Approval Queue
        const approvalEl = document.getElementById('neena-lab-approval-queue');
        if (approvalEl) {
            if (data.approval_queue && data.approval_queue.length > 0) {
                approvalEl.innerHTML = data.approval_queue.map(a =>
                    `<div class="lab-item-row" style="flex-direction: column; align-items: flex-start; gap: 8px;">
                        <div style="display: flex; width: 100%; justify-content: space-between; align-items: center;">
                            <span class="badge badge-info">${a.type} (ID: ${a.id})</span>
                            <span class="lab-item-meta">${a.status}</span>
                        </div>
                        <div style="font-size: 0.9rem; color: var(--text-muted); background: rgba(255,255,255,0.03); padding: 8px; border-radius: 4px; width: 100%; box-sizing: border-box; white-space: pre-wrap;">${a.content_preview || '(empty)'}</div>
                        <div style="display: flex; gap: 8px; margin-top: 4px;">
                            <button class="btn btn-primary btn-sm" onclick="approveQueueItem(${a.id})" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-check"></i> Approve
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="rejectQueueItem(${a.id})" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-xmark"></i> Reject
                            </button>
                        </div>
                    </div>`
                ).join('');
            } else {
                approvalEl.innerHTML = '<p class="empty-state">No items pending approval.</p>';
            }
        }

        // Broadcast readiness (M4-A3.5)
        const readinessEl = document.getElementById('neena-lab-broadcast-readiness');
        if (readinessEl && data.broadcast_readiness) {
            const br = data.broadcast_readiness;
            const audio = br.audio || {};
            const az = br.azuracast || {};
            const ttsLabel = audio.tts_status === 'real_available' ? 'real available' : 'simulated only';
            const ttsBadge = audio.tts_status === 'real_available' ? 'success' : 'warning';
            const azLabel = az.ready_for_real_push ? 'ready' : 'missing config';
            const azBadge = az.ready_for_real_push ? 'success' : 'danger';
            const blockers = (br.blockers || []).slice(0, 4).join(', ');
            readinessEl.innerHTML = `
                <div style="display:flex; flex-wrap:wrap; gap:6px; align-items:center;">
                    <span class="badge badge-${ttsBadge}">TTS: ${ttsLabel}</span>
                    <span class="badge badge-secondary">${audio.active_provider || 'unknown'}</span>
                    <span class="badge badge-${azBadge}">AzuraCast write: ${azLabel}</span>
                    ${br.real_push_ready ? '<span class="badge badge-success">real push ready</span>' : ''}
                </div>
                ${blockers ? `<div style="margin-top:4px; color: var(--warning, #e6a23c); font-size:0.85rem;">Blocked: ${blockers}</div>` : ''}
                <div style="margin-top:4px; font-size:0.85rem; opacity:0.9;">${br.m4_a4_note || 'Stream verification M4-A4 tabhi chalega jab real AzuraCast push success hoga.'}</div>
            `;
        }

        // Broadcast Capsules (M4-A1)
        const capsulesEl = document.getElementById('neena-lab-broadcast-capsules');
        if (capsulesEl) {
            if (data.broadcast_capsules && data.broadcast_capsules.length > 0) {
                capsulesEl.innerHTML = data.broadcast_capsules.map(c => {
                    const preview = (c.script_text || '').substring(0, 140);
                    const audioBadge = c.audio_truth_level || 'none';
                    const azBadge = c.azuracast_status || 'not_sent';
                    const streamBadge = c.stream_verification_status || 'unknown';
                    const streamBadgeClass = streamBadge === 'verified' ? 'success'
                        : (streamBadge === 'uploaded_not_playing' ? 'warning'
                        : (streamBadge === 'failed' ? 'danger' : 'secondary'));
                    const playbackStatus = c.playback_status || (c.metadata && c.metadata.playback_status) || '';
                    const playbackBadge = playbackStatus || (streamBadge === 'verified' ? 'verified' : '');
                    const canEnsurePlayback = (azBadge === 'uploaded' || azBadge === 'scheduled');
                    const npSnap = c.last_now_playing_snapshot || (c.metadata && c.metadata.stream_verification_summary && c.metadata.stream_verification_summary.now_playing_snapshot);
                    const npSummary = npSnap ? `<div class="lab-item-meta">now-playing: ${npSnap.artist ? npSnap.artist + ' - ' : ''}${npSnap.title || '?'} | stream listeners: ${npSnap.listeners ?? '?'}</div>` : '';
                    const azMediaId = c.azuracast_media_id || (c.metadata && c.metadata.azuracast_media_id) || '';
                    const azPlaylistId = c.azuracast_playlist_id || '';
                    const canSendAzura = c.azuracast_push_allowed === true;
                    const azBlockReason = c.azuracast_push_block_reason || '';
                    const streamNote = (c.stream_verification_note || (azBadge === 'uploaded' || azBadge === 'scheduled' ? 'Stream verification pending M4-A4' : ''));
                    const approvalId = c.approval_queue_id;
                    const audioUrl = c.audio_url || '';
                    const audioPlayable = c.audio_playable && audioUrl;
                    const simNote = c.audio_truth_level === 'simulated'
                        ? '<div class="lab-item-meta" style="color: var(--warning, #e6a23c);">Simulated audio broadcast-ready nahi hai</div>' : '';
                    const approveBtns = c.approval_status === 'pending' && approvalId ? `
                        <button class="btn btn-primary btn-sm" onclick="approveQueueItem(${approvalId})" style="padding: 2px 8px; font-size: 0.8rem;">
                            <i class="fa-solid fa-check"></i> Approve
                        </button>
                        <button class="btn btn-secondary btn-sm" onclick="rejectQueueItem(${approvalId})" style="padding: 2px 8px; font-size: 0.8rem;">
                            <i class="fa-solid fa-xmark"></i> Reject
                        </button>` : '';
                    const audioGenBtn = c.approval_status === 'approved' ? `
                        <button class="btn btn-primary btn-sm" onclick="generateCapsuleAudio(${c.id}, ${!!audioPlayable})" style="padding: 2px 8px; font-size: 0.8rem;">
                            <i class="fa-solid fa-volume-high"></i> ${audioPlayable ? 'Regenerate Audio' : 'Generate Audio'}
                        </button>` : (c.approval_status === 'pending' ? `
                        <span class="lab-item-meta">Audio blocked until approved</span>` : '');
                    const audioPlayer = audioPlayable ? `
                        <audio controls src="${audioUrl}" style="width: 100%; max-width: 280px; height: 32px; margin-top: 4px;"></audio>
                        ${simNote}` : '';
                    return `<div class="lab-item-row broadcast-capsule-row" style="flex-direction: column; align-items: flex-start; gap: 6px;">
                        <div style="display: flex; width: 100%; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
                            <span class="badge badge-info">#${c.id} ${c.capsule_type || 'unknown'}</span>
                            <span class="lab-item-meta">${c.created_at || ''}</span>
                        </div>
                        <div style="font-size: 0.85rem;"><strong>${c.title || 'Untitled'}</strong></div>
                        <div class="capsule-status-badges" style="display: flex; flex-wrap: wrap; gap: 4px;">
                            <span class="badge badge-${c.approval_status === 'approved' ? 'success' : (c.approval_status === 'rejected' ? 'danger' : 'warning')}">approval: ${c.approval_status}</span>
                            <span class="badge badge-secondary">audio: ${audioBadge}</span>
                            <span class="badge badge-${azBadge === 'uploaded' || azBadge === 'scheduled' ? 'success' : (azBadge === 'failed' ? 'danger' : (azBadge === 'blocked' ? 'danger' : 'warning'))}">azura: ${azBadge}</span>
                            <span class="badge badge-${streamBadgeClass}">stream: ${streamBadge}</span>
                            ${playbackBadge ? `<span class="badge badge-${playbackBadge === 'verified' ? 'success' : (playbackBadge === 'queued' ? 'info' : 'warning')}">playback: ${playbackBadge}</span>` : ''}
                        </div>
                        ${npSummary}
                        ${azMediaId ? `<div class="lab-item-meta">media id: ${azMediaId}${azPlaylistId ? ' | playlist: ' + azPlaylistId : ''}</div>` : ''}
                        ${streamNote ? `<div class="lab-item-meta">${streamNote}</div>` : ''}
                        ${azBlockReason ? `<div class="lab-item-meta" style="color: var(--warning, #e6a23c);">${azBlockReason}</div>` : ''}
                        <div style="font-size: 0.85rem; color: var(--text-muted); background: rgba(255,255,255,0.03); padding: 8px; border-radius: 4px; width: 100%; box-sizing: border-box; white-space: pre-wrap;">${preview}${(c.script_text || '').length > 140 ? '...' : ''}</div>
                        ${audioPlayer}
                        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 4px; align-items: center;">
                            ${approveBtns}
                            ${audioGenBtn}
                            ${canSendAzura ? `
                            <button class="btn btn-primary btn-sm" onclick="sendCapsuleAzuracast(${c.id})" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-cloud-arrow-up"></i> Send to AzuraCast
                            </button>` : `
                            <button class="btn btn-secondary btn-sm" disabled title="${azBlockReason || 'AzuraCast push not ready'}" style="padding: 2px 8px; font-size: 0.8rem; opacity: 0.65;">
                                <i class="fa-solid fa-cloud-arrow-up"></i> AzuraCast blocked
                            </button>`}
                            ${canEnsurePlayback ? `
                            <button class="btn btn-primary btn-sm" onclick="ensureCapsulePlayback(${c.id}, 'auto')" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-forward"></i> Ensure Playback
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="ensureCapsulePlayback(${c.id}, 'queue_now', 60)" title="Queue + watch 60s" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-bolt"></i> Queue Now
                            </button>` : ''}
                            ${canEnsurePlayback ? `
                            <button class="btn btn-primary btn-sm" onclick="verifyCapsuleStream(${c.id}, false)" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-tower-broadcast"></i> Verify Stream
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="verifyCapsuleStream(${c.id}, true)" title="60s watch poll" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-clock"></i> Watch 60s
                            </button>` : ''}
                        </div>
                    </div>`;
                }).join('');
            } else {
                capsulesEl.innerHTML = '<p class="empty-state">No broadcast capsules yet.</p>';
            }
        }

        // Playout Ready / Approved Scripts
        const playoutEl = document.getElementById('neena-lab-playout-ready');
        if (playoutEl) {
            if (data.playout_ready && data.playout_ready.length > 0) {
                playoutEl.innerHTML = data.playout_ready.map(p =>
                    `<div class="lab-item-row" style="flex-direction: column; align-items: flex-start; gap: 8px;">
                        <div style="display: flex; width: 100%; justify-content: space-between; align-items: center;">
                            <span class="badge badge-success">${p.asset_type} (ID: ${p.id})</span>
                            <span class="lab-item-meta">${p.status}</span>
                        </div>
                        <div style="font-size: 0.9rem; color: var(--text-muted); background: rgba(255,255,255,0.03); padding: 8px; border-radius: 4px; width: 100%; box-sizing: border-box; white-space: pre-wrap;">${(p.content_data || '').substring(0, 120)}...</div>
                        <div style="display: flex; gap: 8px; margin-top: 4px;">
                            <button class="btn btn-primary btn-sm" onclick="generateVoicePreview(${p.id})" style="padding: 2px 8px; font-size: 0.8rem;">
                                <i class="fa-solid fa-microphone"></i> Generate Voice Preview
                            </button>
                        </div>
                    </div>`
                ).join('');
            } else {
                playoutEl.innerHTML = '<p class="empty-state">No approved scripts.</p>';
            }
        }

        // Voice Assets
        const voiceEl = document.getElementById('neena-lab-voice-assets');
        if (voiceEl) {
            if (data.voice_assets && data.voice_assets.length > 0) {
                voiceEl.innerHTML = data.voice_assets.map(v => {
                    const filename = v.audio_file_path ? v.audio_file_path.split(/[\\/]/).pop() : '';
                    const statusText = v.status || 'unknown';
                    const badgeClass = statusText.includes('simulated') ? 'warning' : (statusText.includes('real') || statusText === 'rendered' ? 'success' : 'info');
                    const playHtml = filename ? 
                        `<audio controls src="/playout/voice_assets/${filename}" style="width: 100%; max-width: 250px; height: 28px; margin-top: 6px;"></audio>` : '';
                    return `<div class="lab-item-row" style="flex-direction: column; align-items: flex-start; gap: 4px;">
                        <div style="display: flex; justify-content: space-between; width: 100%; align-items: center;">
                            <span class="badge badge-${badgeClass}">voice preview</span>
                            <span class="lab-item-meta">${statusText}</span>
                        </div>
                        <span style="font-size: 0.9rem;">${(v.text_content || '').substring(0, 80)}...</span>
                        ${playHtml}
                    </div>`;
                }).join('');
            } else {
                voiceEl.innerHTML = '<p class="empty-state">No voice assets generated.</p>';
            }
        }

        // Schedule
        const schedEl = document.getElementById('neena-lab-schedule');
        if (schedEl) {
            const readiness = data.schedule_readiness || {};
            const readinessHtml = readiness.status ? `
                <div class="lab-item-row">
                    <span class="badge badge-${readiness.status === 'partial' ? 'warning' : 'info'}">${readiness.status}</span>
                    <strong>Schedule readiness</strong>
                    <span class="lab-item-meta">${readiness.truth_level || 'unknown'}</span>
                    <span style="width: 100%; color: var(--text-muted);">${readiness.message || ''}</span>
                </div>
            ` : '';
            if (data.schedule && data.schedule.length > 0) {
                schedEl.innerHTML = readinessHtml + data.schedule.map(s =>
                    `<div class="lab-item-row">
                        <strong>${s.time_slot}</strong> — ${s.program_name}
                        ${s.description ? `<span class="lab-item-meta">${s.description}</span>` : ''}
                    </div>`
                ).join('');
            } else {
                schedEl.innerHTML = readinessHtml || '<p class="empty-state">No schedule data.</p>';
            }
        }

        // Source Tools
        const toolsEl = document.getElementById('neena-lab-source-tools');
        if (toolsEl) {
            if (data.source_tools && data.source_tools.length > 0) {
                toolsEl.innerHTML = data.source_tools.map(t => {
                    const status = t.status || 'unknown';
                    const badge = status === 'success' ? 'success' : (status === 'unavailable' || status === 'failed' ? 'warning' : 'info');
                    const configured = t.real_source_configured ? 'configured' : 'not configured';
                    const fallback = t.fallback_available ? 'fallback yes' : 'fallback no';
                    const manual = t.manual_available ? 'manual yes' : 'manual no';
                    const blocked = t.blocked_by || 'none';
                    return `<div class="lab-item-row" style="flex-direction: column; align-items: flex-start; gap: 6px;">
                        <div style="display: flex; width: 100%; justify-content: space-between; align-items: center; gap: 8px;">
                            <span class="badge badge-${badge}">${status}</span>
                            <strong>${t.label || t.tool_name}</strong>
                            <span class="lab-item-meta">${t.truth_level || 'unknown'}</span>
                        </div>
                        <span class="lab-item-meta" style="margin-left: 0;">${configured} | ${fallback} | ${manual}</span>
                        <span style="color: var(--text-muted);">Blocked: ${blocked}</span>
                    </div>`;
                }).join('');
            } else {
                toolsEl.innerHTML = '<p class="empty-state">No source tool readiness data.</p>';
            }
        }

        // Activity
        const actEl = document.getElementById('neena-lab-activity');
        if (actEl) {
            if (data.activity && data.activity.length > 0) {
                actEl.innerHTML = data.activity.map(a => {
                    const t = a.timestamp ? new Date(a.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) : '';
                    return `<div class="log-item-row"><span class="time">[${t}]</span> <strong>${a.type}</strong>: ${a.detail}</div>`;
                }).join('');
            } else {
                actEl.innerHTML = '<p class="empty-state">No recent activity.</p>';
            }
        }

    } catch (e) {
        console.error('Neena Lab fetch error:', e);
    }
}


// 3. WHATSAPP LINKER GATEWAY STATUS
async function fetchWhatsAppGatewayStatus() {
    try {
        const response = await fetch(`${API_BASE}/whatsapp/status`);
        if (response.ok) {
            const data = await response.json();
            
            const badge = document.getElementById('whatsapp-linker-status-badge');
            const qrSpinner = document.getElementById('whatsapp-qr-spinner');
            const qrContainer = document.getElementById('whatsapp-qr-container');
            const qrConnected = document.getElementById('whatsapp-connected-message');
            
            // Sidebar WhatsApp indicator
            const sideDot = document.getElementById('sidebar-whatsapp-dot');
            const sideText = document.getElementById('sidebar-whatsapp-text');
            
            if (!data.gateway_running) {
                badge.textContent = 'GATEWAY OFFLINE';
                badge.className = 'badge badge-danger';
                sideDot.className = 'dot offline';
                sideText.textContent = 'Offline';
                
                qrSpinner.classList.remove('hidden');
                qrSpinner.innerHTML = `
                    <i class="fa-solid fa-circle-exclamation text-danger" style="font-size: 2.5rem; margin-bottom: 12px;"></i>
                    <p style="font-weight: 500;">Local WhatsApp gateway not running.</p>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">Start whatsapp gateway to show QR.</p>
                `;
                qrContainer.classList.add('hidden');
                qrConnected.classList.add('hidden');
            } else if (data.status === 'connected') {
                badge.textContent = 'CONNECTED';
                badge.className = 'badge badge-success';
                sideDot.className = 'dot live';
                sideText.textContent = 'Connected';
                
                qrSpinner.classList.add('hidden');
                qrContainer.classList.add('hidden');
                qrConnected.classList.remove('hidden');
                
                document.getElementById('whatsapp-linked-phone').textContent = `Phone: ${data.phone || 'Ready'}`;
            } else if (data.status === 'qr_ready' && data.qr_code_data) {
                badge.textContent = 'SCAN QR CODE';
                badge.className = 'badge badge-warning';
                sideDot.className = 'dot offline';
                sideText.textContent = 'Syncing...';
                
                qrSpinner.classList.add('hidden');
                qrConnected.classList.add('hidden');
                qrContainer.classList.remove('hidden');
                
                const qrImg = document.getElementById('whatsapp-qr-img');
                if (data.qr_code_data.startsWith('data:image/')) {
                    qrImg.src = data.qr_code_data;
                } else {
                    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=230x230&data=${encodeURIComponent(data.qr_code_data)}`;
                }
            } else {
                badge.textContent = data.status ? data.status.toUpperCase() : 'OFFLINE';
                badge.className = 'badge badge-warning';
                sideDot.className = 'dot offline';
                sideText.textContent = 'Syncing...';
                
                qrSpinner.classList.remove('hidden');
                qrSpinner.innerHTML = `
                    <i class="fa-solid fa-circle-notch fa-spin" style="font-size: 2.5rem; margin-bottom: 12px; color: var(--cyan);"></i>
                    <p>Status: ${data.status ? data.status.toUpperCase() : 'PENDING'}. Waiting for QR...</p>
                `;
                qrContainer.classList.add('hidden');
                qrConnected.classList.add('hidden');
            }
        }
    } catch (e) {
        const sideDot = document.getElementById('sidebar-whatsapp-dot');
        sideDot.className = 'dot offline';
        document.getElementById('sidebar-whatsapp-text').textContent = 'Offline';
    }
}

async function triggerRestartWhatsAppGateway() {
    if (confirm('Kya aap sach mein WhatsApp Gateway ko restart karna chahte hain?')) {
        try {
            const response = await adminFetch(`${API_BASE}/runtime/command`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command_type: 'RESTART_WHATSAPP' })
            });
            if (response.ok) {
                alert('WhatsApp gateway reboot job queued successfully. Please wait 10 seconds...');
                setTimeout(fetchWhatsAppGatewayStatus, 2000);
            }
        } catch(e) {}
    }
}


function updateModelSelectorDropdown(fallbackVerified) {
    const modelSelect = document.getElementById('chat-model-selector');
    if (!modelSelect) return;
    
    const currentVal = modelSelect.value;
    modelSelect.innerHTML = '';
    
    const optAuto = document.createElement('option');
    optAuto.value = 'auto';
    optAuto.textContent = 'Auto';
    modelSelect.appendChild(optAuto);
    
    const optFlash = document.createElement('option');
    optFlash.value = 'gemini-3.1-flash-lite';
    optFlash.textContent = 'Gemini 3.1 Flash Lite';
    modelSelect.appendChild(optFlash);
    
    if (fallbackVerified) {
        const optGemma = document.createElement('option');
        optGemma.value = 'gemma-4-31b';
        optGemma.textContent = 'Gemma 4 31B';
        modelSelect.appendChild(optGemma);
    }
    
    const optLocal = document.createElement('option');
    optLocal.value = 'local-control-only';
    optLocal.textContent = 'Local Control Only';
    modelSelect.appendChild(optLocal);
    
    if (Array.from(modelSelect.options).some(o => o.value === currentVal)) {
        modelSelect.value = currentVal;
    } else {
        modelSelect.value = 'auto';
    }
}

// 4. SETTINGS & RATES EDITING LOGIC
async function fetchStationSettingsConfig() {
    try {
        const response = await fetch(`${API_BASE}/config/status`);
        if (response.ok) {
            const data = await response.json();
            
            // Sidebar Gemini label
            const geminiDot = document.getElementById('sidebar-gemini-sidebar');
            const geminiText = document.getElementById('sidebar-gemini-text');
            if (geminiDot) {
                if (data.gemini_api_key_configured) {
                    geminiDot.className = 'dot live';
                    if (geminiText) geminiText.textContent = 'Active';
                    else geminiDot.parentNode.querySelector('strong').textContent = 'Active';
                } else {
                    geminiDot.className = 'dot offline';
                    if (geminiText) geminiText.textContent = 'Missing';
                    else geminiDot.parentNode.querySelector('strong').textContent = 'Missing';
                }
            }
            updateModelSelectorDropdown(data.fallback_model_verified);
        }
    } catch(e) {}
}

async function saveStationAPIKeys() {
    const geminiKey = document.getElementById('setting-gemini-key').value.trim();
    const elevenKey = document.getElementById('setting-elevenlabs-key').value.trim();
    
    if (!geminiKey) {
        alert('Gemini key is required to configure Neena!');
        return;
    }
    
    try {
        const response = await adminFetch(`${API_BASE}/config/key`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                gemini_key: geminiKey,
                elevenlabs_key: elevenKey
            })
        });
        
        if (response.ok) {
            alert('Settings credentials successfully saved and synchronized!');
            fetchStationSettingsConfig();
        } else {
            alert('Failed to save settings.');
        }
    } catch(e) {
        alert('Server connection error saving keys.');
    }
}

async function fetchNeenaAgentFlags() {
    const list = document.getElementById('neena-agent-flags-list');
    if (!list) return;
    try {
        const response = await adminFetch(`${API_BASE}/neena/feature-flags`);
        if (!response || response.status === 401) {
            list.innerHTML = '<p class="empty-state">Unlock Command Center to manage flags.</p>';
            return;
        }
        if (!response.ok) {
            list.innerHTML = '<p class="empty-state">Flags load failed.</p>';
            return;
        }
        const data = await response.json();
        const flags = (data && data.flags) || {};
        const keys = Object.keys(flags);
        if (!keys.length) {
            list.innerHTML = '<p class="empty-state">No agent flags.</p>';
            return;
        }
        list.innerHTML = '';
        keys.forEach((key) => {
            const f = flags[key] || {};
            const row = document.createElement('div');
            row.className = 'neena-flag-row';
            const checked = f.enabled ? 'checked' : '';
            const overrideNote = f.override === null || f.override === undefined
                ? `env default: ${f.env_default ? 'on' : 'off'}`
                : `override: ${f.override ? 'on' : 'off'} (env ${f.env_default ? 'on' : 'off'})`;
            row.innerHTML = `
                <label>
                    <input type="checkbox" data-flag="${key}" ${checked} onchange="toggleNeenaAgentFlag(this)">
                    <span>
                        <span class="flag-title">${f.label || key}</span>
                        <span class="flag-desc">${f.description || ''}</span>
                        <span class="flag-meta">${key} · ${overrideNote}</span>
                    </span>
                </label>
            `;
            list.appendChild(row);
        });
    } catch (e) {
        list.innerHTML = '<p class="empty-state">Flags unavailable.</p>';
    }
}

async function toggleNeenaAgentFlag(el) {
    if (!el || !el.dataset.flag) return;
    const flag = el.dataset.flag;
    const enabled = !!el.checked;
    try {
        const response = await adminFetch(`${API_BASE}/neena/feature-flags`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ flag, enabled }),
        });
        if (!response.ok) {
            el.checked = !enabled;
            alert('Flag update failed.');
            return;
        }
        fetchNeenaAgentFlags();
        refreshOwnerWorkingContext();
    } catch (e) {
        el.checked = !enabled;
        alert('Flag update connection error.');
    }
}

async function fetchMarketRatesList() {
    const container = document.getElementById('market-rates-items-container');
    try {
        const response = await fetch(`${API_BASE}/market-rates`);
        if (response.ok) {
            const rates = await response.json();
            
            if (rates.length === 0) {
                container.innerHTML = '<p class="empty-state">No market items configured.</p>';
                return;
            }
            
            container.innerHTML = '';
            rates.forEach(item => {
                const card = document.createElement('div');
                card.className = 'rate-editor-card';
                
                card.innerHTML = `
                    <div class="rate-item-meta">
                        <h4>${item.item_name}</h4>
                        <span>Category: ${item.category.toUpperCase()} (${item.unit})</span>
                    </div>
                    <div class="rate-inputs-row">
                        <input type="text" value="${item.price}" class="input-sci price-input" id="rate-price-${item.id}">
                        <input type="text" value="${item.price_change}" class="input-sci change-input" id="rate-change-${item.id}">
                        <select class="select-trend" id="rate-trend-${item.id}">
                            <option value="up" ${item.trend === 'up' ? 'selected' : ''}>📈 Up</option>
                            <option value="down" ${item.trend === 'down' ? 'selected' : ''}>📉 Down</option>
                        </select>
                        <button class="btn btn-secondary btn-sm" onclick="saveMarketItemRate('${item.item_name}', ${item.id})">
                            Update
                        </button>
                    </div>
                `;
                container.appendChild(card);
            });
        }
    } catch (e) {
        container.innerHTML = '<p class="empty-state text-danger">Failed to connect to rates database.</p>';
    }
}

async function saveMarketItemRate(itemName, id) {
    const price = document.getElementById(`rate-price-${id}`).value.trim();
    const change = document.getElementById(`rate-change-${id}`).value.trim();
    const trend = document.getElementById(`rate-trend-${id}`).value;
    
    if (!price || !change) {
        alert('Price and Change fields cannot be empty!');
        return;
    }
    
    try {
        const response = await adminFetch(`${API_BASE}/market-rates/${encodeURIComponent(itemName)}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                price: price,
                trend: trend,
                price_change: change
            })
        });
        
        if (response.ok) {
            alert(`Market rate updated successfully for ${itemName}!`);
            fetchMarketRatesList();
        } else {
            alert('Failed to update market rate.');
        }
    } catch(e) {
        alert('Network failure syncing market rates.');
    }
}

async function fetchPendingDedications() {
    try {
        const response = await fetch(`${API_BASE}/neena/dedications`);
        if (response.ok) {
            const dedications = await response.json();
            const container = document.getElementById('admin-dedications-list');
            
            if (!container) return;
            
            if (dedications.length === 0) {
                container.innerHTML = '<p class="empty-state">No pending song dedications.</p>';
                return;
            }
            
            container.innerHTML = '';
            dedications.forEach(item => {
                const row = document.createElement('div');
                row.className = 'dedication-item-row';
                row.innerHTML = `
                    <div>Listener <strong>${item.listener_name}</strong> from <strong>${item.region}</strong> is requesting:</div>
                    <div style="margin-top: 4px; font-weight: 600; color: var(--cyan);"><i class="fa-solid fa-music"></i> ${item.song_title}</div>
                    ${item.message ? `<div style="margin-top: 4px; font-style: italic; color: var(--text-muted); opacity: 0.85;">"${item.message}"</div>` : ''}
                    <div class="meta">
                        <span>Dedicated to: <strong>${item.dedicated_to}</strong></span>
                        <span>${new Date(item.created_at || Date.now()).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                `;
                container.appendChild(row);
            });
        }
    } catch (e) {
        console.error("Failed to fetch song dedications:", e);
    }
}

let isBackendOffline = false;
let backendRetryCountdown = 5;
let offlineCountdownInterval = null;

async function checkBackendHealth() {
    try {
        const res = await fetch(`${API_BASE}/config/status`, { cache: 'no-store' });
        if (res.ok) {
            setBackendOfflineState(false);
            return true;
        }
    } catch (e) {
        // network error
    }
    setBackendOfflineState(true);
    return false;
}

function setBackendOfflineState(offline) {
    if (offline === isBackendOffline) return;
    isBackendOffline = offline;
    
    const micBtn = document.getElementById('cockpit-mic-btn');
    const pills = document.querySelectorAll('.cockpit-quick-pills button');
    const manualInput = document.getElementById('owner-console-input');
    const manualBtn = document.querySelector('.chat-input-bar button');
    const unlockPhrase = document.getElementById('cockpit-unlock-phrase-input');
    const unlockBtn = document.querySelector('#cockpit-manual-unlock-panel button');
    const testVoiceBtn = document.getElementById('btn-test-voice');
    const diagnosticBtns = document.querySelectorAll('#launch-status-badges button');
    const sidebarServerDot = document.getElementById('sidebar-server-dot');
    const sidebarServerText = document.getElementById('sidebar-server-text');
    
    if (offline) {
        // Show Offline status in UI
        setNeenaState('error', 'Backend offline / recovering');
        if (sidebarServerDot) {
            sidebarServerDot.className = 'dot offline';
            sidebarServerText.textContent = 'Offline';
        }
        
        // Disable controls
        if (micBtn) micBtn.disabled = true;
        pills.forEach(btn => btn.disabled = true);
        if (manualInput) manualInput.disabled = true;
        if (manualBtn) manualBtn.disabled = true;
        if (unlockPhrase) unlockPhrase.disabled = true;
        if (unlockBtn) unlockBtn.disabled = true;
        if (testVoiceBtn) testVoiceBtn.disabled = true;
        diagnosticBtns.forEach(btn => btn.disabled = true);
        
        // Start countdown to retry
        startOfflineRetryCountdown();
    } else {
        // Restore controls
        setNeenaState('online', 'Neena Online');
        if (sidebarServerDot) {
            sidebarServerDot.className = 'dot live';
            sidebarServerText.textContent = 'Online';
        }
        
        if (micBtn) micBtn.disabled = false;
        pills.forEach(btn => btn.disabled = false);
        if (manualInput) manualInput.disabled = false;
        if (manualBtn) manualBtn.disabled = false;
        if (unlockPhrase) unlockPhrase.disabled = false;
        if (unlockBtn) unlockBtn.disabled = false;
        if (testVoiceBtn) testVoiceBtn.disabled = false;
        diagnosticBtns.forEach(btn => btn.disabled = false);
        
        // Stop countdown
        stopOfflineRetryCountdown();
        
        // Fetch fresh data
        fetchCockpitData();
    }
}

function startOfflineRetryCountdown() {
    if (offlineCountdownInterval) clearInterval(offlineCountdownInterval);
    backendRetryCountdown = 5;
    
    updateOfflineStatusLabel();
    
    offlineCountdownInterval = setInterval(async () => {
        backendRetryCountdown--;
        if (backendRetryCountdown <= 0) {
            // Check health
            const ok = await checkBackendHealth();
            if (ok) {
                return;
            }
            backendRetryCountdown = 5;
        }
        updateOfflineStatusLabel();
    }, 1000);
}

function stopOfflineRetryCountdown() {
    if (offlineCountdownInterval) {
        clearInterval(offlineCountdownInterval);
        offlineCountdownInterval = null;
    }
}

function updateOfflineStatusLabel() {
    const label = `Backend offline / recovering. Retrying in ${backendRetryCountdown}s…`;
    setNeenaState('error', label);
}
