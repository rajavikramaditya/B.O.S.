// ==== Orai Command Center — command-center cockpit shell (state, mic, quick actions) module ====
// Auto-split from the former monolithic app.js (M6 Phase 4c, SRP).
// Loaded as an ordered classic <script>; shares one global scope with sibling
// modules (core.js, voice.js, admin.js, cockpit.js, panels.js, app.js).

async function runLiveWhatNow() {
    if (neenaChatInFlight) return;
    neenaChatInFlight = true;
    setQuickActionsDisabled(true);
    setNeenaState('thinking', 'Live state check…');
    let staleState = false;
    try {
        const response = await adminFetchWithTimeout(`${API_BASE}/neena/live-ops/quick`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'what_now' }),
        }, LIVE_STATE_TIMEOUT_MS);
        const data = await response.json().catch(() => ({}));
        if (response.ok && data.handled) {
            liveStateStale = false;
            announceNeena(data.reply, { appendChat: true, meta: data, taskFeed: 'What now (live)', taskType: 'success', voicePriority: 'final' });
        } else {
            staleState = true;
            liveStateStale = true;
            announceNeena('Live state check fail ho gaya. Main cached status use kar rahi hoon.', {
                taskType: 'error',
                taskFeed: 'Live state unavailable',
                speak: false,
            });
            if (Date.now() - lastLiveStateFailSpeakAt > LIVE_STATE_STALE_SPEAK_MS) {
                lastLiveStateFailSpeakAt = Date.now();
                queueNeenaVoice('Live state check fail ho gaya. Main cached status use kar rahi hoon.', {
                    priority: 'error',
                    dedupeKey: 'live_state_fail',
                });
            }
        }
    } catch (e) {
        staleState = true;
        liveStateStale = true;
        const isTimeout = e && (e.name === 'AbortError');
        const msg = isTimeout
            ? 'Live state check timeout ho gaya. Main cached status use kar rahi hoon.'
            : 'Live state check fail ho gaya. Main cached status use kar rahi hoon.';
        announceNeena(msg, { taskFeed: 'Live state unavailable', taskType: 'error', speak: false });
        if (Date.now() - lastLiveStateFailSpeakAt > LIVE_STATE_STALE_SPEAK_MS) {
            lastLiveStateFailSpeakAt = Date.now();
            queueNeenaVoice(msg, { priority: 'error', dedupeKey: 'live_state_fail' });
        }
    } finally {
        neenaChatInFlight = false;
        setQuickActionsDisabled(false);
        setNeenaState('online', staleState ? 'Live state stale' : 'Neena Online');
    }
}

const COCKPIT_ACTION_UI = {
    station_status: {
        start: 'Checking status…',
        success: 'Status ready',
        timeout: 'Status check slow ho gaya. Backend busy lag raha hai.',
        fail: 'Status check failed',
    },
    diagnostics_fast: {
        start: 'Fast diagnostics running…',
        success: 'Fast diagnostics ready',
        timeout: 'Diagnostics slow ho gaye — Manual drawer se Deep Diagnostics try kariye.',
        fail: 'Fast diagnostics failed',
    },
    diagnostics: {
        start: 'Fast diagnostics running…',
        success: 'Fast diagnostics ready',
        timeout: 'Diagnostics slow ho gaye — Manual drawer se Deep Diagnostics try kariye.',
        fail: 'Fast diagnostics failed',
    },
    diagnostics_deep: {
        start: 'Deep diagnostics running…',
        success: 'Deep diagnostics complete',
        timeout: 'Deep diagnostics abhi bhi chal rahe hain — thodi der baad check kariye.',
        fail: 'Deep diagnostics failed',
    },
    verify_latest_stream: {
        start: 'Verifying stream on air…',
        success: 'Stream verify complete',
        timeout: 'Verification start nahi ho paayi.',
        timeoutPoll: 'Stream verification abhi complete nahi hui. Main final result nahi de paayi.',
        fail: 'Stream verify failed',
    },
    creative_job: {
        start: 'Creative job chal rahi hai…',
        success: 'Creative job complete',
        timeout: 'Creative job slow ho gayi.',
        timeoutPoll: 'Creative job abhi complete nahi hui.',
        fail: 'Creative job failed',
    },
};

const CC_THEME_KEY = 'cc-theme';
const CC_SIDEBAR_KEY = 'cc-sidebar-collapsed';

function initCcChrome() {
    const theme = localStorage.getItem(CC_THEME_KEY) || 'light';
    document.body.setAttribute('data-theme', theme);
    syncCcThemeIcon(theme);
    if (localStorage.getItem(CC_SIDEBAR_KEY) === '1' && window.matchMedia('(min-width: 961px)').matches) {
        document.body.classList.add('cc-sidebar-collapsed');
    }
}

function syncCcThemeIcon(theme) {
    const icon = document.getElementById('cc-theme-icon');
    if (!icon) return;
    icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}

function toggleCcTheme() {
    const cur = document.body.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    document.body.setAttribute('data-theme', next);
    localStorage.setItem(CC_THEME_KEY, next);
    syncCcThemeIcon(next);
}

function toggleCcSidebar() {
    const mobile = window.matchMedia('(max-width: 960px)').matches;
    if (mobile) {
        document.body.classList.toggle('cc-sidebar-open');
        return;
    }
    document.body.classList.toggle('cc-sidebar-collapsed');
    localStorage.setItem(
        CC_SIDEBAR_KEY,
        document.body.classList.contains('cc-sidebar-collapsed') ? '1' : '0'
    );
}

function closeCcSidebarDrawer() {
    document.body.classList.remove('cc-sidebar-open');
}

// Globals
function switchTab(tabId) {
    if (tabId === 'whatsapp') tabId = 'settings';
    activeTab = tabId;
    
    // Toggle active buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    const activeBtn = document.getElementById(`tab-btn-${tabId}`);
    if (activeBtn) activeBtn.classList.add('active');
    
    // Toggle active screen panels
    document.querySelectorAll('.screen-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    const activePanel = document.getElementById(`screen-${tabId}`);
    if (activePanel) activePanel.classList.add('active');
    
    // Update header title/subtitle
    const titleEl = document.getElementById('viewport-title');
    const subtitleEl = document.getElementById('viewport-subtitle');
    
    if (tabId === 'console') {
        titleEl.textContent = 'Neena';
        subtitleEl.textContent = 'Station manager agent — operations from here.';
        fetchCockpitData();
    } else if (tabId === 'neenalab') {
        titleEl.textContent = 'Lab';
        subtitleEl.textContent = 'Scripts, approvals, pipeline, schedule, source tools.';
        fetchNeenaLabData();
        fetchCockpitData();
    } else if (tabId === 'monitor') {
        titleEl.textContent = 'Monitor';
        subtitleEl.textContent = 'Telemetry, stream health, station readiness.';
        fetchCockpitData();
    } else if (tabId === 'settings') {
        titleEl.textContent = 'Settings';
        subtitleEl.textContent = 'Gateway, credentials, voice, agent flags, market rates.';
        fetchMarketRatesList();
        fetchWhatsAppGatewayStatus();
        fetchNeenaAgentFlags();
    }
    closeCcSidebarDrawer();
}
function setQuickActionsDisabled(disabled) {
    document.querySelectorAll('.quick-action-btn, .cockpit-pill').forEach(btn => {
        btn.disabled = disabled;
        btn.classList.toggle('is-busy', disabled);
    });
}

function runOwnerQuickAction(commandText) {
    runVoiceCommand(commandText);
}

function runVoiceCommand(commandText, options) {
    const inputEl = document.getElementById('owner-console-input');
    if (!inputEl || neenaChatInFlight) return;
    if (!isCommandCenterUnlocked()) {
        notifyAdminLocked();
        return;
    }
    if (typeof setHeardLine === 'function') {
        setHeardLine(`Heard: ${commandText}`);
    } else {
        const heard = document.getElementById('neena-heard-line');
        if (heard) heard.textContent = `Heard: ${commandText}`;
    }
    inputEl.value = commandText;
    inputEl.dataset.creativeCommand = options && options.creative ? '1' : '';
    submitOwnerConsoleMessage();
}

function initOwnerVoice() {
    const saved = sessionStorage.getItem(SPEAK_PREF_KEY);
    const defaultOn = saved === null || saved === '1';
    getSpeakCheckboxElements().forEach(el => {
        el.checked = defaultOn;
        el.addEventListener('change', () => syncSpeakCheckboxes(el.checked));
    });
    const savedMode = sessionStorage.getItem(VOICE_MODE_KEY);
    syncVoiceModeSelector(savedMode || 'auto');
    refreshFallbackVoiceStatus();
    if (!('speechSynthesis' in window)) {
        speechSynthAvailable = false;
        if (!speechWarningShown) {
            speechWarningShown = true;
            appendCockpitTask('Browser speech unavailable — Backend voice mode recommended.', 'info');
        }
        syncVoiceModeSelector('backend');
        setVoiceStatusBadge('idle', 'Backend/Edge mode');
        return;
    }
    speechSynthAvailable = true;
    const primeVoices = () => {
        window.speechSynthesis.getVoices();
        speechVoicesPrimed = true;
        refreshVoiceEngineStatus();
    };
    primeVoices();
    window.speechSynthesis.addEventListener('voiceschanged', primeVoices);
    document.body.addEventListener('click', function unlockOwnerVoice() {
        voiceOwnerGestureUnlocked = true;
        primeVoices();
        document.body.removeEventListener('click', unlockOwnerVoice);
    }, { once: true });
    refreshVoiceEngineStatus();
}

function handleNeenaUiAction(uiAction, meta) {
    if (!uiAction || !uiAction.type) return;
    if (uiAction.type === 'open_latest_script') {
        switchTab('neenalab');
        fetchNeenaLabData();
        appendCockpitTask(
            uiAction.capsule_id
                ? `Opened Capsule #${uiAction.capsule_id} in Neena Lab`
                : 'Neena Lab opened for script review',
            'info'
        );
        return;
    }
    if (uiAction.type === 'poll_cockpit_job' && uiAction.job_id) {
        const actionKey = uiAction.action_key || 'verify_latest_stream';
        const ui = COCKPIT_ACTION_UI[actionKey] || {
            success: 'Job complete',
            fail: 'Job failed',
            timeoutPoll: 'Job timeout',
        };
        pollCockpitJobInBackground(uiAction.job_id, ui, actionKey);
        return;
    }
    if (uiAction.type === 'refresh_cockpit') {
        fetchCockpitData();
        fetchNeenaLabData();
        return;
    }
    if (uiAction.type === 'admin_lock') {
        lockCommandCenter();
    }
}

async function runCockpitAction(action) {
    if (neenaChatInFlight) return;
    if (!isCommandCenterUnlocked()) {
        notifyAdminLocked();
        return;
    }
    const actionKey = action || 'station_status';
    const ui = COCKPIT_ACTION_UI[actionKey] || {
        start: 'Running action…',
        success: 'Action complete',
        timeout: 'Action timeout — dubara try kariye.',
        fail: 'Action failed',
    };
    const timeoutMs = COCKPIT_ACTION_TIMEOUT_MS[actionKey] || 15000;
    const isBackgroundAction = actionKey === 'verify_latest_stream' || actionKey === 'diagnostics_deep';

    neenaChatInFlight = true;
    setQuickActionsDisabled(true);
    if (isBackgroundAction) {
        setNeenaState('executing', ui.start);
    } else {
        setNeenaState('thinking', ui.start);
    }
    appendCockpitTask(ui.start, 'command');
    await announceNeena(ui.start, { showCockpit: true, speak: true });
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    let releasedForBackground = false;
    try {
        const body = { action: actionKey };
        if (actionKey === 'verify_latest_stream') body.watch_seconds = 30;
        const response = await adminFetch(`${API_BASE}/neena/cockpit-action`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: controller.signal,
        });
        if (response.status === 401) {
            setNeenaState('error', 'Locked');
            await announceNeena('Sir, Command Center locked hai. Pehle owner unlock phrase boliye.', {
                taskFeed: 'Auth locked',
                taskType: 'error',
                speak: true,
            });
            return;
        }
        const data = await response.json().catch(() => ({}));
        if (response.ok && data.ok && data.mode === 'background' && data.job_id) {
            deliverNeenaReply(data.message || ui.start, {
                appendChat: true,
                meta: { action: actionKey, job_id: data.job_id },
            });
            appendCockpitTask(`Background job ${data.job_id} (${data.latency_ms || '?'}ms)`, 'info');
            neenaChatInFlight = false;
            setQuickActionsDisabled(false);
            releasedForBackground = true;
            pollCockpitJobInBackground(data.job_id, ui, actionKey);
            return;
        }
        if (response.ok && data.ok) {
            const msg = data.message || 'Done.';
            deliverNeenaReply(msg, {
                appendChat: true,
                meta: { action_type: data.action, latency_ms: data.latency_ms },
            });
            appendCockpitTask(`${ui.success} (${data.latency_ms || '?'}ms)`, 'success');
            setNeenaState('online', 'Neena Online');
            fetchCockpitData();
        } else {
            const reason = data.message || data.detail || ui.fail;
            deliverNeenaReply(reason, { appendChat: true });
            appendCockpitTask(`${ui.fail}: ${reason}`.substring(0, 120), 'error');
            setNeenaState('error', 'Error');
        }
    } catch (e) {
        if (e && e.name === 'AbortError') {
            deliverNeenaReply(ui.timeout, { appendChat: true });
            appendCockpitTask(ui.timeout, 'error');
        } else {
            deliverNeenaReply('Server se connect nahi ho paya.', { appendChat: true });
            appendCockpitTask(ui.fail, 'error');
        }
        setNeenaState('error', 'Connection Error');
    } finally {
        clearTimeout(timeoutId);
        if (!releasedForBackground) {
            neenaChatInFlight = false;
            setQuickActionsDisabled(false);
            setNeenaState('online', 'Neena Online');
        }
    }
}

async function fetchLaunchHealthBadges() {
    try {
        const response = await fetch(`${API_BASE}/neena/launch-health`, { cache: 'no-store' });
        if (!response.ok) return;
        const data = await response.json();
        const setBadge = (id, label, value, okValues) => {
            const el = document.getElementById(id);
            if (!el) return;
            const normalized = (value || 'unknown').toString();
            const isOk = okValues.some(v => normalized.toLowerCase().includes(v));
            el.className = `launch-badge ${isOk ? 'badge-ok' : 'badge-warn'}`;
            el.innerHTML = `${label}: <strong>${normalized}</strong>`;
        };
        setBadge('badge-backend', 'Backend', data.backend || 'online', ['online', 'active']);
        setBadge('badge-postgres', 'PostgreSQL', data.postgres, ['healthy']);
        setBadge('badge-pgvector', 'pgvector', data.pgvector, ['active']);
        setBadge('badge-redis', 'Redis', data.redis, ['healthy']);
        const wa = (data.whatsapp_gateway || 'offline').toString();
        const waEl = document.getElementById('badge-whatsapp');
        if (waEl) {
            const offline = wa.toLowerCase().includes('offline') || wa.toLowerCase().includes('unavailable');
            waEl.className = `launch-badge ${offline ? 'badge-warn' : 'badge-ok'}`;
            const display = offline ? 'offline — non-blocking' : wa;
            waEl.innerHTML = `WhatsApp: <strong>${display}</strong>`;
        }
    } catch (e) {
        // Silent — badges are informational only
    }
}

function updateProviderStatusWidget(metadata) {
    if (!metadata) return;
    
    const selectedModel = metadata.selected_model || 'auto';
    const actualModel = metadata.actual_model || 'none';
    const source = metadata.source || 'local_tool';
    const llmStatus = metadata.llm ? metadata.llm.status : 'not_used';
    const latency = metadata.timing ? `${metadata.timing.total_ms}ms` : '—';
    const fallbackUsed = metadata.fallback_used ? 'Yes' : 'No';
    
    const modelEl = document.getElementById('status-val-model');
    const actualEl = document.getElementById('status-val-actual');
    const sourceEl = document.getElementById('status-val-source');
    const llmStatusEl = document.getElementById('status-val-llm-status');
    const latencyEl = document.getElementById('status-val-latency');
    const fallbackEl = document.getElementById('status-val-fallback');
    
    if (modelEl) modelEl.innerHTML = `Selected: <strong>${selectedModel.replace(/-/g, ' ').toUpperCase()}</strong>`;
    if (actualEl) actualEl.innerHTML = `Last Model: <strong>${actualModel.replace(/-/g, ' ').toUpperCase()}</strong>`;
    if (sourceEl) sourceEl.innerHTML = `Source: <strong>${source.replace(/_/g, ' ').toUpperCase()}</strong>`;
    if (llmStatusEl) llmStatusEl.innerHTML = `LLM Status: <strong>${llmStatus.toUpperCase()}</strong>`;
    if (latencyEl) latencyEl.innerHTML = `Latency: <strong>${latency}</strong>`;
    if (fallbackEl) fallbackEl.innerHTML = `Fallback: <strong>${fallbackUsed}</strong>`;
    
    // Support showing cooldown details in widget
    const cooldownDiv = document.getElementById('status-val-cooldown');
    const cooldownDivider = document.getElementById('status-divider-cooldown');
    if (cooldownDiv && cooldownDivider) {
        if (llmStatus === 'cooldown' || metadata.model_rate_limited) {
            cooldownDiv.style.display = 'inline';
            cooldownDivider.style.display = 'inline';
            const hint = metadata.retry_after_hint ? ` (${metadata.retry_after_hint})` : '';
            cooldownDiv.innerHTML = `Cooldown: <strong class="text-warning">Active${hint}</strong>`;
        } else {
            cooldownDiv.style.display = 'none';
            cooldownDivider.style.display = 'none';
        }
    }
}

// =============================================================================
// M4-A5R — Voice-first Command Center cockpit
// =============================================================================

let voiceRecognition = null;
let voiceListening = false;
let cockpitCapsulesCache = [];

const NEENA_STATES = {
    online: { label: 'Neena Online', cls: 'online' },
    listening: { label: 'Listening…', cls: 'listening' },
    thinking: { label: 'Processing command…', cls: 'thinking' },
    executing: { label: 'Executing…', cls: 'executing' },
    broadcasting: { label: 'Broadcasting', cls: 'broadcasting' },
    error: { label: 'Error', cls: 'error' },
};

function syncGateGuideMode(mode) {
    const stage = document.getElementById('cc-gate-neena');
    const avatar = document.getElementById('cc-gate-avatar');
    if (!stage) return;
    let next = mode || 'idle';
    if (next === 'thinking') next = 'listening';
    if (!['idle', 'listening', 'speaking'].includes(next)) next = 'idle';
    stage.classList.remove('is-idle', 'is-listening', 'is-thinking', 'is-speaking');
    stage.classList.add(`is-${next}`);
    if (avatar) avatar.dataset.mode = next;
}

function setNeenaState(state, customLabel) {
    const cfg = NEENA_STATES[state] || NEENA_STATES.online;
    const label = customLabel || cfg.label;
    const title = document.getElementById('neena-state-title');
    const badge = document.getElementById('cockpit-state-label');
    const dot = document.getElementById('cockpit-state-dot');
    const orb = document.getElementById('neena-orb-wrap');
    if (title) title.textContent = label;
    if (badge) badge.textContent = label;
    if (dot) dot.className = `state-dot ${cfg.cls}`;
    if (orb) orb.className = `neena-orb-wrap state-${cfg.cls}`;

    let gateMode = 'idle';
    if (cfg.cls === 'listening') gateMode = 'listening';
    else if (cfg.cls === 'thinking') gateMode = 'thinking';
    else if (cfg.cls === 'broadcasting') gateMode = 'speaking';
    else if (voiceSpeaking) gateMode = 'speaking';
    syncGateGuideMode(gateMode);

    const gateState = document.getElementById('cc-gate-state-label');
    if (gateState && document.body.classList.contains('cc-locked')) {
        gateState.textContent = label;
    }
}

function appendCockpitTask(text, type = 'info') {
    const feed = document.getElementById('cockpit-task-feed');
    if (!feed) return;
    const normalized = (text || '').trim().toLowerCase();
    if (normalized === lastCockpitTaskText && Date.now() - lastCockpitTaskAt < 10000) return;
    lastCockpitTaskText = normalized;
    lastCockpitTaskAt = Date.now();
    const item = document.createElement('div');
    item.className = `task-item task-${type}`;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    item.innerHTML = `<span class="task-time">${time}</span> ${text}`;
    feed.prepend(item);
    while (feed.children.length > 10) feed.removeChild(feed.lastChild);
}

function showCockpitReply(text) {
    const el = document.getElementById('cockpit-voice-reply');
    const clean = (text || '').replace(/<[^>]+>/g, '').replace(/\*.*?\*/g, '').trim();
    if (el) el.textContent = clean;
    // Never mirror Hinglish speak text onto the locked gate chrome.
    if (document.body.classList.contains('cc-locked')) return;
    const gateReply = document.getElementById('cc-gate-reply');
    if (gateReply) gateReply.textContent = clean;
}

function shortReplyForVoice(text) {
    const clean = (text || '').replace(/<[^>]+>/g, '').replace(/\*.*?\*/g, '').trim();
    const limit = (typeof MAX_VOICE_CHARS === 'number' && MAX_VOICE_CHARS > 0) ? MAX_VOICE_CHARS : 1200;
    if (clean.length <= limit) return clean;
    const cut = clean.substring(0, limit);
    const lastStop = Math.max(
        cut.lastIndexOf('।'),
        cut.lastIndexOf('.'),
        cut.lastIndexOf('!'),
        cut.lastIndexOf('?'),
        cut.lastIndexOf('\n')
    );
    if (lastStop > limit * 0.55) return cut.substring(0, lastStop + 1).trim();
    return cut.trim();
}

function toggleManualDrawer() {
    const drawer = document.getElementById('cockpit-manual-drawer');
    if (drawer) drawer.classList.toggle('hidden');
}

function initVoiceRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const note = document.getElementById('voice-fallback-note');
    if (!SpeechRecognition) {
        if (note) note.classList.remove('hidden');
        return;
    }
    voiceRecognition = new SpeechRecognition();
    voiceRecognition.lang = VOICE_COMMAND_LANG;
    voiceRecognition.interimResults = false;
    voiceRecognition.maxAlternatives = 1;
    voiceRecognition.onstart = () => {
        voiceListening = true;
        const isUnlock = voiceRecognitionMode === 'unlock';
        if (isUnlock) {
            transitionToState('LOCKED', 'Listening for unlock phrase…');
            const lbl = document.getElementById('cockpit-mic-label');
            if (lbl) lbl.textContent = 'Listening… tap to stop';
        } else {
            transitionToState('LISTENING');
        }
    };
    voiceRecognition.onend = () => {
        voiceListening = false;
        voiceRecognitionMode = 'command';
        if (!neenaChatInFlight && currentState !== 'PROCESSING') {
            if (!isCommandCenterUnlocked()) {
                transitionToState('LOCKED');
            } else {
                transitionToState('IDLE');
            }
        }
    };
    voiceRecognition.onerror = () => {
        voiceRecognitionMode = 'command';
        appendCockpitTask('Voice recognition error', 'error');
        if (!isCommandCenterUnlocked()) {
            transitionToState('LOCKED');
        } else {
            transitionToState('ERROR', 'Mic Error');
        }
    };
    voiceRecognition.onresult = (ev) => {
        const transcript = ev.results[0][0].transcript.trim();
        if (typeof setHeardLine === 'function') {
            setHeardLine(`Heard: ${transcript}`);
        } else {
            const heard = document.getElementById('neena-heard-line');
            if (heard) heard.textContent = `Heard: ${transcript}`;
        }
        voiceRecognitionMode = 'command';
        if (!isCommandCenterUnlocked()) {
            handleUnlockPhraseHeard(ev);
            return;
        }
        appendCockpitTask(`Heard: ${transcript}`, 'command');
        runVoiceCommand(transcript);
    };
}

function toggleVoiceListening() {
    if (!isCommandCenterUnlocked()) {
        startUnlockListening();
        return;
    }
    voiceRecognitionMode = 'command';
    setVoiceRecognitionLang('command');
    if (!voiceRecognition) {
        toggleManualDrawer();
        return;
    }

    if (currentState === 'SPEAKING') {
        try { window.speechSynthesis.cancel(); } catch (e) {}
        if (currentCockpitAudio) {
            try { currentCockpitAudio.pause(); } catch (e) {}
        }
        voiceSpeaking = false;
        voiceQueue = [];
        appendCockpitTask('Voice interrupted by owner', 'info');
        
        transitionToState('LISTENING');
        try {
            voiceRecognition.start();
        } catch (e) { /* ignore */ }
        return;
    }

    if (currentState === 'LISTENING' || currentState === 'WAITING_FOR_FOLLOWUP') {
        try { voiceRecognition.stop(); } catch (e) {}
        transitionToState('IDLE');
        return;
    }

    if (currentState === 'PROCESSING') {
        if (activeChatAbortController) {
            activeChatAbortController.abort();
            activeChatAbortController = null;
        }
        appendCockpitTask('Processing cancelled by owner', 'info');
        transitionToState('LISTENING');
        try {
            voiceRecognition.start();
        } catch (e) { /* ignore */ }
        return;
    }

    if (currentState === 'IDLE' || currentState === 'ERROR') {
        transitionToState('LISTENING');
        try {
            voiceRecognition.start();
        } catch (e) {
            appendCockpitTask('Mic start failed — use Manual drawer', 'error');
            transitionToState('ERROR', 'Mic Error');
        }
        return;
    }
}
